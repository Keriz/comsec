#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <x86intrin.h>

#include "krypto.h"

#define array_size(x) (sizeof(x) / sizeof(*(x)))

#ifdef HARDENED
extern uint64_t Te0[];
extern uint64_t Te1[];
#else
extern uint64_t Te0[];
#endif

int main(void)
{
	unsigned char out[8];
	unsigned char in[8];

	krypto_sign_data(out, in, 8);
	
    return 0;
}
