#pragma once

int krypto_sign_data(unsigned char *out, unsigned char *in, size_t len);
